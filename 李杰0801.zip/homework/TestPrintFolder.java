package homework;

import file.FileFilter;

import java.io.File;

/**
 * @description: TODO 介绍类
 * @author: 22783
 * @date: 2023/8/1
 **/
public class TestPrintFolder {

    //todo 打印该目录下面的所有层级关系
    public void testPrint(File file,int level){
        if (file.isDirectory()){
            File[] files = file.listFiles();
            if (files!=null){
                for (File fileSingle: files) {
                    printLevel(level);
                    System.out.println("子文件名: = " + fileSingle.getName());

                    if (fileSingle.isDirectory()) {
                        testPrint(fileSingle,level+1);
                    }
                }
            }
        }
    }

    private void printLevel(int level) {
        for (int i = 0; i < level; i++) {
            System.out.print("--");
        }
    }

    public static void main(String[] args) {
        TestPrintFolder printFolder = new TestPrintFolder();

        String pathName = "D://test//";

        File file = new File(pathName);
        printFolder.testPrint(file,0);

    }
}
