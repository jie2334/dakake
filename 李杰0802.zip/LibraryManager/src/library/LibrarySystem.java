package library;

import sun.text.resources.FormatData;

import java.io.*;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @description: TODO 介绍类
 * @author: 22783
 * @date: 2023/7/26
 **/
public class LibrarySystem {

    private Library library;


    private Map<String, Reader> readerMap;


    public LibrarySystem(Library library, Map<String, Reader> readerMap) {
        this.library = library;
        this.readerMap = readerMap;
    }


    /**
     * 打印图书馆里面的所有书籍
     *
     * @return list
     */
    public List<Book> printBookByDate() {
        List<Book> list = getLibrary().getBookList();
        list.sort(Comparator.comparing(Book::getPublicationDate));
        return list;
    }


    /**
     * 图书馆借阅书籍
     *
     * @param reader
     * @param format
     * @throws ParseException
     */
    public List<BorrowRecord> startBorrow(Reader reader, DateFormat format, String name) throws ParseException {

        /*判断是否map里面包含uuid*/
        Map<String, Reader> map = getReaderMap();
        boolean containsKey = map.containsKey(reader.getUuid());

        if (containsKey) {
            List<Book> bookList = library.getBookList();
            if (!(name == null)) {
                for (Book book : bookList) {
                    if (name.equals(book.getName()) && (!book.isBorrow())) {
                        System.out.println("该图书在馆,可以借阅!");
                        //bookList里面的此书状态改变,并且更新借阅时间
                        book.setBorrow(true);
                        //获取当前时间
                        Date date = new Date();
                        format.format(date);
                        book.setStorageDate(date);
                        //登记归还时间
                        Date returnDate = new Date();
                        //在此人的借阅记录里面新增一条借阅记录
                        //每个读者的借阅记录
                        List<BorrowRecord> recordList = reader.getRecordList();

                        recordList.add(new BorrowRecord(book, book.getStorageDate(), returnDate));
                        System.out.println("你的名字是: " + reader.getName());
                        return recordList;
                    }

                }
            }
        }
        return null;
    }


    /**
     * 归还书籍
     *
     * @return
     */
    public List<BorrowRecord> returnBook(Reader reader, String returnName) {


        List<BorrowRecord> records = reader.getRecordList();
        //删除这条记录
        Iterator<BorrowRecord> iterator = records.listIterator();
        while (iterator.hasNext()) {
            BorrowRecord next = iterator.next();
            if (returnName.equals(next.getBook().getName())) {
                System.out.println("输入正确,有这条记录");
                //更新状态
                Book recordBook = next.getBook();
                recordBook.setBorrow(false);
                recordBook.setStorageDate(null);
                iterator.remove();
            }

        }
        return records;
    }

    /**
     * 读者注册写入reader的属性
     *
     * @param reader
     * @param pathName
     */
    public void saveOnFile(Reader reader, String pathName) {//假定传进来的路径是:  D://test//test.txt
        //读者的uuid
        String readerUuid = reader.getUuid();
        //读者的name
        String name = reader.getName();
        //注册的时间
        String registrationTime = reader.getRegistrationTime().toString();

        try {
            FileWriter writer = new FileWriter(pathName + "test.txt");

            writer.write(readerUuid);
            writer.append(":");
            writer.write(name);
            writer.append(":");
            writer.write(registrationTime);
            writer.close();

            //字符串拼接新建txt文件写入reader书籍
            File file = new File(pathName + readerUuid + ".txt");

            FileWriter fileWriter = new FileWriter(file);

            for (Map.Entry<String, Reader> readerEntry : readerMap.entrySet()) {
                fileWriter.write(String.valueOf(readerEntry.getValue().getRecordList()));
            }
            fileWriter.close();
            readerMap.put(readerUuid, reader);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }


    public ArrayList<Object> readFile(Reader reader, String path) throws RuntimeException {

        ArrayList<Object> list = new ArrayList<>();

        //当system创建的时候 从文件中读出属性，保存到hashMap中
        try  {
            FileReader fileReader = new FileReader(path + reader.getUuid()+".txt");

            BufferedReader bufferedReader = new BufferedReader(fileReader);

            while (bufferedReader.read()!=-1) {

                String line = bufferedReader.readLine();

                String[] split = line.split(":");
                String uuid = split[0];
                String name = split[1];
                String date = split[2];

                SimpleDateFormat format = new SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy");

                Date parse = format.parse(date);


                Reader newReader = new Reader(uuid, name, parse);

                List<BorrowRecord> recordList = newReader.getRecordList();

                list.add(newReader);
                list.addAll(recordList);
            }

        } catch (IOException | ParseException e) {
            throw new RuntimeException(e);
        }
        return list;
    }


    public Library getLibrary() {
        return library;
    }

    public void setLibrary(Library library) {
        this.library = library;
    }


    public Map<String, Reader> getReaderMap() {
        return readerMap;
    }

    public void setReaderMap(Map<String, Reader> readerMap) {
        this.readerMap = readerMap;
    }

    @Override
    public String toString() {
        return "LibrarySystem{" + "library=" + library + ", readerMap=" + readerMap + '}';
    }
}
