package library;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @description: 测试类
 * @author: 22783
 * @date: 2023/7/26
 **/
public class TestLib {


    /**
     * @param args
     */
    public static void main(String[] args) throws ParseException {


        //初始化bookList
        List<Book> bookList = new ArrayList<>();
        //日期格式化
        DateFormat format = DateFormat.getDateInstance();

        bookList.add(new Book("平凡的世界", "路遥", format.parse("1993-07-21"), false));
        bookList.add(new Book("人生之路", "路遥", format.parse("1997-08-06"), false));
        bookList.add(new Book("活着", "余华", format.parse("1999-06-21"), false));
        bookList.add(new Book("许三观卖血记", "余华", format.parse("1987-05-21"), false));
        bookList.add(new Book("数据结构与算法", "Java大神", format.parse("2002-08-09"), false));
        bookList.add(new Book("C语言基础入门", "谭浩强", format.parse("2003-06-07"), false));
        bookList.add(new Book("Java通关之路", "java之父", format.parse("2012-07-08"), false));
        bookList.add(new Book("那年我双手插兜", "卢本伟", format.parse("2013-03-23"), false));

        //初始化图书馆
        Library library = new Library("小杰图书馆", "软件新城春和路88号", bookList);

        System.out.println(library.toString());

        //初始化借阅人
        Reader reader1 = new Reader("胡彦斌", new Date(), new ArrayList<BorrowRecord>(), String.valueOf(UUID.randomUUID()));
        Reader reader2 = new Reader("吴彦祖", new Date(), new ArrayList<BorrowRecord>(), String.valueOf(UUID.randomUUID()));
        Reader jiejie = new Reader("jiejie", new Date(), new ArrayList<BorrowRecord>(), String.valueOf(UUID.randomUUID()));

        HashMap<String, Reader> hashMap = new HashMap<>();
        hashMap.put(reader1.getUuid(), reader1);
        hashMap.put(reader2.getUuid(), reader2);

        //构造函数传参
        LibrarySystem system = new LibrarySystem(library, hashMap);
        System.out.println("system = " + system);
        //将图书列表按照日期的升序排列

        System.out.println("========================================= ");

        List<Book> books = system.printBookByDate();
        System.out.println("图书馆的books = " + books);
        System.out.println("========================================= ");
        System.out.println("reader1 = " + reader1);

        //测试借阅书籍方法
        try{
            String bookName = "平凡的世界";
            List<BorrowRecord> records = system.startBorrow(reader1, format,bookName);
            System.out.println("您的借阅列表records = " + records);
            System.out.println("========================================= ");
            system.returnBook(reader1,bookName);
        }catch (Exception e){
            e.printStackTrace();
        }
        System.out.println("reader1 = " + reader1.getUuid());

        system.saveOnFile(reader1,"D://test//");
        System.out.println("library = " + library.getBookList());

        system.readFile(reader1,"D://test//");

        system.readFile(system.getReaderMap().get(reader1.getUuid()),"D://test//");

       /* try {

            List<BorrowRecord> records = system.startBorrow(reader2, format);
            System.out.println("您的借阅列表records = " + records);
            System.out.println("========================================= ");

        }catch (Exception e){
            e.printStackTrace();
        }
        System.out.println("library = " + library.getBookList());
        System.out.println("========================================= ");


        //测试归还书籍方法
        List<BorrowRecord> records = system.returnBook(reader1);

        System.out.println("您的借阅列表records = " + records);
        System.out.println("========================================= ");
        System.out.println("library = " + library.getBookList());
        System.out.println(system.toString());*/
        /*system.getReaderMap().put(reader1.getUuid(), reader1);
        Reader reader = system.getByUuid(reader1.getUuid());
        System.out.println("reader = " + reader);*/

    }
}
