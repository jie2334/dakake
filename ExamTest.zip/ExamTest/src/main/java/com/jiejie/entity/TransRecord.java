package com.jiejie.entity;

import lombok.Data;

/**
 * @description: TransRecord
 * @author: 22783
 * @date: 2023/8/11
 **/
@Data
public class TransRecord {

    private String id;

    private Double price;

    private String detail;

}
